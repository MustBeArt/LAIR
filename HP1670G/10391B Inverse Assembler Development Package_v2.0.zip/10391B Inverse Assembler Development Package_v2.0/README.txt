This directory contains software for the 10391B Inverse Assembler Development Package
version 2.0 and the format utility for the 16600 and 16700 series analyzers.  The format
utility replaces IALDOWN when a 16600 or 16700 logic analysis system is being used.  IALDOWN
will still be used for the 16500, 1660 and 1670 logic analyzers.  

To install the format utility, copy the files onto a flexible disk.  Then place the disk in
the disk drive of the 16600 or 16700 frame.  Use the software installer (System Admin, Install)
to install the files.

This directory was last updated on 11/3/98.
